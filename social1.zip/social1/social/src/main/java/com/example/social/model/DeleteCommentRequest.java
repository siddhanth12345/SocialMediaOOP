package com.example.social.model;

public class DeleteCommentRequest {
    private int commentID;

    public int getCommentID() {
        return commentID;
    }

    public void setCommentID(int commentId) {
        this.commentID = commentId;
    }


}
