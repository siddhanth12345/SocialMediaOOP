package com.example.social.controller;

import com.example.social.model.*;
import com.example.social.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {

    @Autowired
    private Userservice userService;

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody Signup signup){
        return userService.signup(signup.getEmail(), signup.getName(), signup.getPassword());
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Login login) {
        return userService.login(login.getEmail(), login.getPassword());
    }

    @PostMapping("/post")
    public ResponseEntity<String> createPost(@RequestBody CreatePost createPost) {
        return userService.createPost(createPost.getPostBody(), createPost.getUserID());
    }
    @GetMapping("/user")
    public ResponseEntity<Object> getUserDetails(@RequestParam int userID) {
        return userService.getUserDetails(userID);
    }

    @GetMapping("/post")
    public ResponseEntity<Object> getPostDetails(@RequestParam int postID) {
        return userService.getPostDetails(postID);
    }

    @DeleteMapping("/post")
    public ResponseEntity<String> deletePost(@RequestBody DeletePostRequest request) {
        return userService.deletePost(request.getPostID());
    }

    @PatchMapping("/post")
    public ResponseEntity<String> editPost(@RequestBody EditPostRequest request) {
        return userService.editPost(request.getPostID(), request.getPostBody());
    }

    @PostMapping("/comment")
    public ResponseEntity<?> createComment(@RequestBody CreateCommentRequest request) {
        return userService.createComment(request.getCommentBody(), request.getPostID(), request.getUserID());
    }
    @GetMapping("/comment")
    public ResponseEntity<Object> getComment(@RequestParam int commentID) {
        return userService.getComment(commentID);
    }
    @PatchMapping("/comment")
    public ResponseEntity<String> editComment(@RequestBody EditCommentRequest request) {
        return userService.editComment(request.getCommentID(), request.getCommentBody());
    }

    @DeleteMapping("/comment")
    public ResponseEntity<String> deleteComment(@RequestBody DeleteCommentRequest request) {
        return userService.deleteComment(request.getCommentID());
    }
    @GetMapping("/users")
    public ResponseEntity<Object> getUsers() {
        return userService.usersDetail();
    }
    @GetMapping("/")
    public ResponseEntity<Object> getUserFeed() {
        return userService.getUserFeed();
    }
    // other endpoints...
}
