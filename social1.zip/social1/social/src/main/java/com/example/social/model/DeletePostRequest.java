package com.example.social.model;

public class DeletePostRequest {
    private int postID;

    public int getPostID() {
        return postID;
    }

    public void setPostID(int postID) {
        this.postID = postID;
    }
}
