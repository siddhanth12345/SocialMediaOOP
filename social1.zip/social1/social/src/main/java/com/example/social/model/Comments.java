package com.example.social.model;


    public class Comments {
        private int commentID;
        private String commentBody;
        private CommentCreatorDTO commentCreator;

        public int getCommentID() {
            return commentID;
        }

        public void setCommentID(int commentID) {
            this.commentID = commentID;
        }

        public String getCommentBody() {
            return commentBody;
        }

        public void setCommentBody(String commentBody) {
            this.commentBody = commentBody;
        }

        public CommentCreatorDTO getCommentCreator() {
            return commentCreator;
        }

        public void setCommentCreator(CommentCreatorDTO commentCreator) {
            this.commentCreator = commentCreator;
        }
// Constructors, getters, and setters
    }


