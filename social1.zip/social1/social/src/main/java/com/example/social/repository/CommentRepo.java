package com.example.social.repository;

import com.example.social.model.Comment;
import com.example.social.model.Post;
import com.example.social.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository


public interface CommentRepo extends JpaRepository<Comment, Integer> {
}
