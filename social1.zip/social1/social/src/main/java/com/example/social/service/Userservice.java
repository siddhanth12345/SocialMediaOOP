package com.example.social.service;

import com.example.social.model.*;
import com.example.social.repository.CommentRepo;
import com.example.social.repository.PostRepo;
import com.example.social.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class Userservice {

    @Autowired
    private UserRepo userRepository;
    @Autowired
    private PostRepo postRepository;
    @Autowired
    private CommentRepo commentRepository;

    String dateString;

    public ResponseEntity<String> signup(String email, String name, String password) {
        // Check if the user already exists
        if (userRepository.existsByEmail(email)) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Forbidden, Account already exists\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }

        // Create a new user entity
        User newUser = new User();
        newUser.setEmail(email);
        newUser.setName(name);
        newUser.setPassword(password);

        // Save the new user to the database
        userRepository.save(newUser);

        return ResponseEntity.status(HttpStatus.CREATED).body("Account Creation Successful");
    }

    public ResponseEntity<String> login(String email, String password) {
        // Find the user by email
        Optional<User> userOptional = userRepository.findByEmail(email);

        if(userOptional.isEmpty())
        {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"User does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
        // If user not found or password doesn't match, return error
        if (!userOptional.get().getPassword().equals(password)) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Username/Password Incorrect\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }


        return ResponseEntity.ok("Login Successful");
    }

    public ResponseEntity<Object> getUserDetails(int userID) {
        Optional<User> userOptional = userRepository.findById(userID);
        if (userOptional.isEmpty()) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"User does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
        User user = userOptional.get();
        UserDTO userDetailsDTO = new UserDTO();
        userDetailsDTO.setUserID(user.getUserID());
        userDetailsDTO.setName(user.getName());
        userDetailsDTO.setEmail(user.getEmail());
        return ResponseEntity.ok(userDetailsDTO);

    }

    public ResponseEntity<String> createPost(String postBody, int userID) {
        // Check if the user exists
        Optional<User> userOptional = userRepository.findById(userID);
        if (userOptional.isEmpty()) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"User does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }


        // Create the post entity
        Post newPost = new Post();
        newPost.setPostBody(postBody);


        Date inputDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
       // Define the date format
        dateString = formatter.format(inputDate);

        newPost.setDate(dateString.substring(0,10));

        // Save the post to generate the postID
        postRepository.save(newPost);
        // Update the user with the incremented postID


        return ResponseEntity.status(HttpStatus.CREATED).body("Post created successfully");
    }
    public ResponseEntity<Object> getPostDetails(int postID) {
        // Find the post by postID
        Optional<Post> postOptional = postRepository.findById(postID);

        if (postOptional.isPresent()) {
            // If the post exists, retrieve post details
            Post post = postOptional.get();
            List<Comments> commentDetailsList = new ArrayList<>();

            // Iterate through the comments associated with the post and create Comments objects
            for (Comment comment : post.getComments()) {
                CommentCreatorDTO commentDTO = new CommentCreatorDTO();

                // Set userID and name
                commentDTO.setUserID(comment.getUserID());
                commentDTO.setName(comment.getName());
                // Create a CommentDTO object for the comment
                Comments comments = new Comments();
                comments.setCommentID(comment.getCommentID());
                comments.setCommentBody(comment.getCommentBody());
                comments.setCommentCreator(commentDTO);



                commentDetailsList.add(comments);
            }

            // Create a PostDetailsDTO object and populate it with post details and associated comments
            PostDetailsDTO postDetailsDTO = new PostDetailsDTO();
            postDetailsDTO.setPostID(post.getPostID());
            postDetailsDTO.setPostBody(post.getPostBody());
            postDetailsDTO.setDate(post.getDate());
            postDetailsDTO.setComments(commentDetailsList);

            return ResponseEntity.ok(postDetailsDTO);
        } else {
            // If the post does not exist, return an error message
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Post does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<String> deletePost(int postID) {
        // Find the post by postID
        Post post = postRepository.findById(postID).orElse(null);

        if (post != null) {
            // If the post exists, delete it
            postRepository.delete(post);

            return ResponseEntity.ok("Post deleted");
        } else {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Post does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
    }

    public ResponseEntity<String> editPost(int postID, String postBody) {
        // Find the post by postID
        Post post = postRepository.findById(postID).orElse(null);

        if (post != null) {
            // If the post exists, update its postBody
            post.setPostBody(postBody);
            Date inputDate = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            // Define the date format
            dateString = formatter.format(inputDate);
            post.setDate(dateString.substring(0,10));
            postRepository.save(post); // Save the updated post
            return ResponseEntity.ok("Post edited successfully");
        } else {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Post does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);

        }
    }
    public ResponseEntity<String> createComment(String commentBody, int postID, int userID) {
        // Check if the post exists
        Post post = postRepository.findById(postID).orElse(null);
        if (post == null) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Post does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }

        // Check if the user exists
        User user = userRepository.findById(userID).orElse(null);
        if (user == null) {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"User does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }

        // Create the comment creator entity

        // Save the comment creator


        // Create the comment entity
        Comment comment = new Comment();
        comment.setCommentBody(commentBody);
        comment.setPost(post);
        comment.setUserID(userID);
        comment.setName(user.getName());

        // Save the comment
        commentRepository.save(comment);

        return ResponseEntity.status(HttpStatus.CREATED).body("Comment created successfully");
    }

    public ResponseEntity<Object> getComment(int commentID) {
        // Find the comment by commentID
        Optional<Comment> commentOptional = commentRepository.findById(commentID);

        if (commentOptional.isPresent()) {
            // Retrieve the comment
            Comment comment = commentOptional.get();

            // Create a CommentCreatorDTO object and populate it with the comment creator details
            CommentCreatorDTO commentCreatorDTO = new CommentCreatorDTO();
            commentCreatorDTO.setUserID(comment.getUserID());
            commentCreatorDTO.setName(comment.getName());

            // Create a Comments object and populate it with both sets of information
            Comments comments = new Comments();
            comments.setCommentID(comment.getCommentID());
            comments.setCommentBody(comment.getCommentBody());
            comments.setCommentCreator(commentCreatorDTO);

            return ResponseEntity.ok(comments);
        } else {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Comment does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);

        }
    }


    public ResponseEntity<String> editComment(int commentID, String commentBody) {
        // Find the comment by commentID
        Comment comment = commentRepository.findById(commentID).orElse(null);

        if (comment != null) {
            // If the comment exists, update its commentBody
            comment.setCommentBody(commentBody);
            commentRepository.save(comment); // Save the updated comment
            return ResponseEntity.ok("Comment edited successfully");
        } else {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Comment does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
    }
    public ResponseEntity<String> deleteComment(int commentID) {
        // Find the comment by commentID
        Comment comment = commentRepository.findById(commentID).orElse(null);

        if (comment != null) {
            // If the comment exists, delete it
            commentRepository.delete(comment);
            return ResponseEntity.ok("Comment deleted");
        } else {
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "application/json");

            String errorMessage = "{\"error\": \"Comment does not exist\"}";
            return new ResponseEntity<>(errorMessage, headers, HttpStatus.NOT_FOUND);
        }
    }
    public ResponseEntity<Object> usersDetail()
    {
        Iterable<User> users = userRepository.findAll();
        List<UserDTO> userDTOs = new ArrayList<>();
        for (User user : users) {
            UserDTO userDTO = new UserDTO();
            userDTO.setName(user.getName());
            userDTO.setUserID(user.getUserID());
            userDTO.setEmail(user.getEmail());
            userDTOs.add(userDTO);
        }

        return ResponseEntity.ok(userDTOs);
    }
    public ResponseEntity<Object> getUserFeed()
    {
        List<Post> allPosts = postRepository.findAll();

        // Sort the posts based on their creation date in reverse chronological order
        List<Post> sortedPosts = allPosts.stream()
                .sorted(Comparator.comparing(Post::getDate).reversed())
                .collect(Collectors.toList());

        // Create a response object to hold the posts
        List<PostDetailsDTO> postDTOList = new ArrayList<>();
        for (Post post : sortedPosts) {
            PostDetailsDTO postDTO = new PostDetailsDTO();
            postDTO.setPostID(post.getPostID());
            postDTO.setPostBody(post.getPostBody());
            postDTO.setDate(post.getDate());

            // Create CommentDTO objects for each comment in the post
            List<Comments> commentDTOList = new ArrayList<>();
            for (Comment comment : post.getComments()) {
                Comments commentDTO = new Comments();
                commentDTO.setCommentID(comment.getCommentID());
                commentDTO.setCommentBody(comment.getCommentBody());

                // Set CommentCreatorDTO for the comment
                CommentCreatorDTO commentCreatorDTO = new CommentCreatorDTO();
                commentCreatorDTO.setUserID(comment.getUserID());
                commentCreatorDTO.setName(comment.getName());
                commentDTO.setCommentCreator(commentCreatorDTO);

                commentDTOList.add(commentDTO);
            }
            postDTO.setComments(commentDTOList);

            postDTOList.add(postDTO);
        }
        return  ResponseEntity.ok(postDTOList);
    }


    // Other methods...
    // other methods...
}


